@echo off
cd /d "%~dp0"
start "" "%~dp0prince.exe" mod MeninoCactus
